let addButtonTable = document.querySelector('#addDesjejumTable')
addButtonTable.addEventListener('click', () => {

    let addTitle = document.createElement('h2')
    addTitle.innerHTML = ` 
        TABELA DE DESJEJUM
    `

    let buttonAddLinha = document.createElement('div')
    buttonAddLinha.innerHTML = `
        <button id="addLinhaId" class="button-AddlineTable">Adicionar linha</button>
    `

    let addTable = document.createElement('table')
    addTable.innerHTML = `
        <tr><th>Item</th>
        <th>Seg. <br> 21/jul</th>
        <th>Ter. <br> 22/jul</th>
        <th>Qua. <br> 23/jul</th>
        <th>Qui. <br> 24/jul</th>
        <th>Sex. <br> 25/jul</th>
        <th>Sáb. <br> 26/jul</th>
        <th>Dom. <br> 27/jul</th>
        </tr>
    `
    document.querySelector('#menuContent').appendChild(addTitle)
    document.querySelector('#menuContent').appendChild(buttonAddLinha)
    document.querySelector('#menuContent').appendChild(addTable)

    let addLinhaButton = document.querySelector('#addLinhaId');
    addLinhaButton.addEventListener('click', () => {
        console.log('Adding new row to the table');
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
        `;
        addTable.querySelector('tbody').appendChild(newRow);


    });
});

let addButtonTableAlmocoJantarCeia = document.querySelector('#addAlmocoJantarCeiaTable')
addButtonTableAlmocoJantarCeia.addEventListener('click', () => {

    let addTitle = document.createElement('h2')
    addTitle.innerHTML = ` 
        TABELA DE ALMOÇO/JANTAR/CEIA - SABOR DA CASA
    `

    let buttonAddLinha = document.createElement('div')
    buttonAddLinha.innerHTML = `
        <button id="addLinhaId1" class="button-AddlineTable">Adicionar linha</button>
    `

    let addTable = document.createElement('table')
    addTable.innerHTML = `
        <tr><th>Item</th>
        <th>Seg. <br> 21/jul</th>
        <th>Ter. <br> 22/jul</th>
        <th>Qua. <br> 23/jul</th>
        <th>Qui. <br> 24/jul</th>
        <th>Sex. <br> 25/jul</th>
        <th>Sáb. <br> 26/jul</th>
        <th>Dom. <br> 27/jul</th>
        </tr>
    `
    document.querySelector('#menuContent').appendChild(addTitle)
    document.querySelector('#menuContent').appendChild(buttonAddLinha)
    document.querySelector('#menuContent').appendChild(addTable)

    let addLinhaButton = document.querySelector('#addLinhaId1');
    addLinhaButton.addEventListener('click', () => {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
        `;
        addTable.querySelector('tbody').appendChild(newRow);
    });
});

let addButtonTableAlmocoGrill = document.querySelector('#addAlmocoGrillTable')
addButtonTableAlmocoGrill.addEventListener('click', () => {

    let addTitle = document.createElement('h2')
    addTitle.innerHTML = ` 
        TABELA DE ALMOÇO-GRILL
    `

    let buttonAddLinha = document.createElement('div')
    buttonAddLinha.innerHTML = `
        <button id="addLinhaId2" class="button-AddlineTable">Adicionar linha</button>
    `

    let addTable = document.createElement('table')
    addTable.innerHTML = `
        <tr><th>Item</th>
        <th>Seg. <br> 21/jul</th>
        <th>Ter. <br> 22/jul</th>
        <th>Qua. <br> 23/jul</th>
        <th>Qui. <br> 24/jul</th>
        <th>Sex. <br> 25/jul</th>
        <th>Sáb. <br> 26/jul</th>
        <th>Dom. <br> 27/jul</th>
        </tr>
    `
    document.querySelector('#menuContent').appendChild(addTitle)
    document.querySelector('#menuContent').appendChild(buttonAddLinha)
    document.querySelector('#menuContent').appendChild(addTable)
    let addLinhaButton = document.querySelector('#addLinhaId2');
    addLinhaButton.addEventListener('click', () => {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
        `;
        addTable.querySelector('tbody').appendChild(newRow);
    });
});

let addButtonTableAlmocoFastFood = document.querySelector('#addAlmocoFastFoodTable')
addButtonTableAlmocoFastFood.addEventListener('click', () => {

    let addTitle = document.createElement('h2')
    addTitle.innerHTML = ` 
        TABELA DE ALMOÇO-FAST FOOD
    `

    let buttonAddLinha = document.createElement('div')
    buttonAddLinha.innerHTML = `
        <button id="addLinhaId3" class="button-AddlineTable">Adicionar linha</button>
    `

    let addTable = document.createElement('table')
    addTable.innerHTML = `
         <tr><th>Item</th>
        <th>Seg. <br> 21/jul</th>
        <th>Ter. <br> 22/jul</th>
        <th>Qua. <br> 23/jul</th>
        <th>Qui. <br> 24/jul</th>
        <th>Sex. <br> 25/jul</th>
        <th>Sáb. <br> 26/jul</th>
        <th>Dom. <br> 27/jul</th>
        </tr>`
    document.querySelector('#menuContent').appendChild(addTitle)
    document.querySelector('#menuContent').appendChild(buttonAddLinha)
    document.querySelector('#menuContent').appendChild(addTable)
    let addLinhaButton = document.querySelector('#addLinhaId3');
    addLinhaButton.addEventListener('click', () => {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
            <th><input></th>
        `;
        addTable.querySelector('tbody').appendChild(newRow);
    });
});